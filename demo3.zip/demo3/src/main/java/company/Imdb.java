package company;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Imdb {
    public String Getir(String id) {
        try {
            URL url = new URL("https://www.omdbapi.com/?apikey=f2ed8153&i="+id);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            int responseCode = connection.getResponseCode();

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            StringBuilder response = new StringBuilder();

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            reader.close();
            connection.disconnect();
            String[] parts = response.toString().split("\"");
            for (int i = 0; i < parts.length - 1; i++) {
                if (parts[i].equals("Poster")) {
                    String poster = parts[i + 2];
                    return poster;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
}

