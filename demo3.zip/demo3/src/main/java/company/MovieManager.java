package company;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MovieManager {
    public MovieManager(String filePath){

        File file = new File(filePath);
        if (file.exists()) {
            System.out.println("Dosya mevcut.");
        } else {
            System.out.println("Dosya mevcut değil. Dosyanın arandığı yer: "+filePath);
        }
    }

    public List<Movie> MovieList(String filePath){
        List<Movie> movies = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            reader.readLine();

            while ((line = reader.readLine()) != null) {
                String[] values = line.split(";");
                Movie movie = new Movie();
                movie.setNo(Integer.parseInt(values[0]));
                movie.setTitle(values[1]);
                movie.setYear(Integer.parseInt(values[2]));
                movie.setGenre(values[3]);
                movie.setOrigin(values[4]);
                movie.setDirector(values[5]);
                movie.setStar(values[6]);
                movie.setImdbLink(values[7]);

                movies.add(movie);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return movies;
    }

    public Movie MoviePicker(List<Movie> movie){
        Random rndm=new Random();
        int number= rndm.nextInt(movie.size());
        return movie.get(number);
    }

    public void MovieWriteAll(Movie movie){
        System.out.println(movie.getNo()+"|"+movie.getTitle()+"|"+movie.getYear()+"|"+movie.getGenre()+"|"+movie.getOrigin()+"|"+movie.getDirector()+"|"+movie.getStar()+"|"+movie.getImdbLink());

    }

}
