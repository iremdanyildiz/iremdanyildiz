package com.example.demo3;
import company.Imdb;
import company.Movie;
import company.MovieManager;
import javafx.animation.FadeTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class FilmTahminOyunu extends Application {

    private TextField inputField;
    private Label resultLabel;
    private Label remainingLabel;
    private int remainingCount;
    private Button submitButton = new Button("Tahmin Et");

    Movie movie = new Movie();

    public static void main(String[] args) {
        launch(args);
    }

    public String filePath=System.getProperty("user.dir")+"\\imdb_top_250.csv";
    public MovieManager movieManager=new MovieManager(filePath);
    public List<Movie> movieList=movieManager.MovieList(filePath);
    public Movie pickedMovie=movieManager.MoviePicker(movieList);
    public Imdb imdb=new Imdb();
    public String imdbURL;
    public Stage primaryStage;


    @Override
    public void start(Stage primaryStage) {
        movieManager.MovieWriteAll(pickedMovie);
        this.primaryStage = primaryStage;
        remainingCount=5;
        primaryStage.setTitle("Movidle Movie Guessing Game");

        // Input alanı
        inputField = new TextField();
        inputField.setPrefWidth(130);
        inputField.setPromptText("Lütfen bir film ismi girin...");


        // Sonuç
        resultLabel = new Label();
        resultLabel.setFont(Font.font("Arial", 14));
        resultLabel.setTextFill(Color.RED);
        remainingLabel = new Label();
        remainingLabel.setFont(Font.font("Arial", 10));
        remainingLabel.setTextFill(Color.BLUE);
        remainingLabel.setText("Kalan Tahmin Sayısı: "+remainingCount);
        FadeTransition fadeTransition = new FadeTransition(Duration.millis(2000), remainingLabel);
        fadeTransition.setFromValue(1.0);
        fadeTransition.setToValue(0.0);
        fadeTransition.setAutoReverse(true);
        fadeTransition.setCycleCount(FadeTransition.INDEFINITE);
        fadeTransition.play();


        // Gönder düğmesi
        submitButton.setOnAction(e -> handleGuess());


        // Ana düzen
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(inputField, resultLabel, submitButton,remainingLabel);

        Scene scene = new Scene(layout, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private HBox createFeatureBox(Movie movie) {
        HBox featureBox = new HBox(10);
        String userInput = inputField.getText();
        String[] features = {movie.getTitle(), String.valueOf(movie.getYear()), movie.getGenre(), movie.getOrigin(), movie.getDirector(), movie.getStar()};

        for (String feature : features) {
            if (feature.equals(String.valueOf(movie.getYear()))&&pickedMovie.getYear()>movie.getYear()){
                feature=feature+" \u2191";
            }
            else if (feature.equals(String.valueOf(movie.getYear()))&&pickedMovie.getYear()<movie.getYear()){
                feature=feature+" \u2193";
            }
            Label featureLabel = new Label(feature);
            featureLabel.setFont(Font.font("Arial", 12));
            featureLabel.setAlignment(Pos.CENTER);

            // Özellik kutusu
            VBox featureContainer = new VBox();
            featureContainer.setPrefWidth(80);
            featureContainer.setPrefHeight(50);

            if (feature.equals(movie.getTitle())&&pickedMovie.getTitle().equals(movie.getTitle())) {

                featureContainer.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, CornerRadii.EMPTY, Insets.EMPTY)));
            }
            else if (feature.equals(movie.getTitle()) != pickedMovie.getTitle().equals(movie.getTitle())) {
                featureContainer.setBackground(new Background(new BackgroundFill(Color.LIGHTCORAL, CornerRadii.EMPTY, Insets.EMPTY)));
            }
            if (feature.equals(movie.getOrigin())&&pickedMovie.getOrigin().equals(movie.getOrigin())) {

                featureContainer.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, CornerRadii.EMPTY, Insets.EMPTY)));
            }
            else if (feature.equals(movie.getOrigin()) != pickedMovie.getOrigin().equals(movie.getOrigin())) {
                featureContainer.setBackground(new Background(new BackgroundFill(Color.LIGHTCORAL, CornerRadii.EMPTY, Insets.EMPTY)));
            }
            if (feature.equals(movie.getDirector())&&pickedMovie.getDirector().equals(movie.getDirector())) {

                featureContainer.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, CornerRadii.EMPTY, Insets.EMPTY)));
            } else if (feature.equals(movie.getDirector()) != pickedMovie.getDirector().equals(movie.getDirector())) {
                featureContainer.setBackground(new Background(new BackgroundFill(Color.LIGHTCORAL, CornerRadii.EMPTY, Insets.EMPTY)));
            }
            if (feature.equals(movie.getStar())&&pickedMovie.getStar().equals(movie.getStar())) {

                featureContainer.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, CornerRadii.EMPTY, Insets.EMPTY)));
            } else if (feature.equals(movie.getStar())!= pickedMovie.getStar().equals(movie.getStar())) {
                featureContainer.setBackground(new Background(new BackgroundFill(Color.LIGHTCORAL, CornerRadii.EMPTY, Insets.EMPTY)));
            }
            if (feature.equals(movie.getGenre())&&pickedMovie.getGenre().equals(movie.getGenre())) {

                featureContainer.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, CornerRadii.EMPTY, Insets.EMPTY)));
            } else if ( feature.equals(movie.getGenre())!= pickedMovie.getGenre().equals(movie.getGenre())) {
                featureContainer.setBackground(new Background(new BackgroundFill(Color.LIGHTCORAL, CornerRadii.EMPTY, Insets.EMPTY)));
            }
            if (feature.equals(String.valueOf(movie.getYear()))&&pickedMovie.getYear()==(movie.getYear())) {

                featureContainer.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, CornerRadii.EMPTY, Insets.EMPTY)));
            }
            else if (feature.equals(String.valueOf(movie.getYear())+" \u2191")&&pickedMovie.getYear()>movie.getYear()) {

                featureContainer.setBackground(new Background(new BackgroundFill(Color.LIGHTCORAL, CornerRadii.EMPTY, Insets.EMPTY)));
            }
            else if (feature.equals(String.valueOf(movie.getYear())+" \u2193")&&pickedMovie.getYear()<movie.getYear()) {

                featureContainer.setBackground(new Background(new BackgroundFill(Color.LIGHTCORAL, CornerRadii.EMPTY, Insets.EMPTY)));
            }

            featureContainer.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
            featureContainer.getChildren().add(featureLabel);
            featureBox.getChildren().add(featureContainer);
        }

        return featureBox;
    }

    private void handleGuess() {
        String userInput = inputField.getText().toLowerCase(Locale.ROOT);
        if (!userInput.equals("")){
            boolean movieCheck = movieList.stream().anyMatch(film -> film.getTitle().equals(userInput));
            if(movieCheck){
                if (userInput.equals(pickedMovie.getTitle())){
                    // Buraya kazanıldığında ne olacağı eklenecek
                    resultLabel.setText("KAZANDINIZZ");

                    String imageUrl = imdb.Getir(pickedMovie.getImdbLink().split("title/")[1]);

                    Image image = new Image(imageUrl);
                    ImageView imageView = new ImageView(image);


                    VBox root = new VBox(10);
                    root.setPadding(new Insets(20));
                    root.setAlignment(Pos.CENTER);
                    Button backButton = new Button("Tekrar Oyna");

                    root.getChildren().addAll(imageView,backButton,resultLabel);

                    Scene scene = new Scene(root, 450, 600);

                    Stage secondStage = new Stage();
                    secondStage.setTitle("Movidle Movie Guessing Game");
                    secondStage.setScene(scene);
                    secondStage.show();
                    backButton.setOnAction(e -> {
                        pickedMovie=movieManager.MoviePicker(movieList);
                        start(primaryStage);
                        secondStage.close();
                    });
                    primaryStage.close();
                }
                else{
                    Movie tempMovie=movieList.stream()
                            .filter(film -> film.getTitle().equals(userInput.toLowerCase(Locale.ROOT))).findFirst().get();

                    HBox featureBox = createFeatureBox(tempMovie);
                    VBox layout = (VBox) submitButton.getParent();
                    layout.getChildren().add(featureBox);
                    remainingCount--;
                    if(remainingCount<=0){
                        // Buraya tahmin sayısı bittiğinde ne olacağı eklenecek
                        resultLabel.setText("Oyunu kaybettiniz... Film: "+pickedMovie.getTitle());
                        String imageUrl = imdb.Getir(pickedMovie.getImdbLink().split("title/")[1]);

                        Image image = new Image(imageUrl);
                        ImageView imageView = new ImageView(image);


                        VBox root = new VBox(10);
                        root.setPadding(new Insets(20));
                        root.setAlignment(Pos.CENTER);
                        Button backButton = new Button("Tekrar Oyna");

                        root.getChildren().addAll(imageView,backButton,resultLabel);

                        Scene scene = new Scene(root, 450, 600);

                        Stage thirdStage = new Stage();
                        thirdStage.setTitle("Movidle Movie Guessing Game");
                        thirdStage.setScene(scene);
                        thirdStage.show();
                        backButton.setOnAction(e -> {
                            pickedMovie=movieManager.MoviePicker(movieList);
                            start(primaryStage);
                            thirdStage.close();
                        });
                        primaryStage.close();
                    }
                    else{
                        resultLabel.setText("Tahmin Edilen Film: " + userInput);
                        remainingLabel.setText("Kalan Tahmin Sayısı: "+remainingCount);
                    }
                }

            }
            else
                resultLabel.setText("Böyle Bir Film Yok Mu Yoksa Biz Mi Bilmiyoruz :)");
            inputField.setText("");
        }
        else
            resultLabel.setText("Lütfen Tahminde Bulununuz");
    }
}
